import "./Key.css";

// .Key {
//   background-color: grey;
// }

export default function Key() {
  return <div className="Key">Key</div>;
}
