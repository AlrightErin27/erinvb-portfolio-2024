import "./Modal.css";

export default function Modal() {
  return <div className="Modal">Modal</div>;
}
